(function () {
  const root = document.documentElement;
  const button = document.querySelector('[data-theme-toggle]');
  const stored = localStorage.getItem('site-theme');
  if (stored === 'light' || stored === 'dark') root.dataset.theme = stored;
  if (!button) return;
  function update() {
    const dark = root.dataset.theme === 'dark';
    button.textContent = dark ? '☀ Light' : '☾ Dark';
    button.setAttribute('aria-label', dark ? 'Switch to light theme' : 'Switch to dark theme');
  }
  button.addEventListener('click', () => {
    root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('site-theme', root.dataset.theme);
    update();
  });
  update();
})();
